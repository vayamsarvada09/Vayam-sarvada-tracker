VAYAM SARVADA TRACKER — Android build

This is the upgraded version of your original tracker.

Included:
- Instagram Reels: 11 AM, 1 PM, 6 PM, 9 PM, 11 PM
- YouTube Shorts: 11 AM, 1 PM, 6 PM, 9 PM, 11 PM
- Automatic daily records
- Today's 0/10 progress
- Recent 14-day history
- All-10-post streak
- Local/offline storage
- Reset Today's Checks

EASIEST ANDROID BUILD:
1. Install "HTML to APK Builder" from Google Play.
2. Import this ZIP, or select index.html directly.
3. App name: Vayam Sarvada Tracker
4. Package name: com.vayamsarvada.tracker
5. Orientation: Portrait
6. Enable offline/local HTML support.
7. Build the signed APK.
8. Install the APK on your phone.

Important:
The tracker stores its data locally on the phone. Clearing app data or uninstalling the app can erase the history.
Native scheduled notifications are intentionally not included in this first build; the tracker itself is complete and offline.
